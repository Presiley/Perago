package xyz.foobar;

/**
 * Implement or modify this class as you see fit
 *
 */
public class DiffException extends Exception {

	private static final long serialVersionUID = -7698912729249813850L;
	private String errorCode = null;
	
	public DiffException() {
		super();
	}

	public DiffException(String message) {
		super(message);
	}

	public DiffException(String message, Throwable cause) {
		super(message, cause);
	}

	public DiffException(Throwable cause) {
		super(cause);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
