package xyz.foobar;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import xyz.foobar.Diff.Status;

public class DiffService implements DiffEngine{
	
	static Set<Integer> hashcodeList = new HashSet<Integer>();
	static TreeMap<String, Object> prettyDiff = new TreeMap<String, Object>();
	
	@SuppressWarnings("unchecked")
	public <T extends Serializable> T apply(T original, Diff<?> diff) throws DiffException {

		Object modified = (T) original;
		
		Map<String, Object> diffValues = diff.getFields();
		
		try {
			applyChange(modified, diffValues);
			
		} catch (Exception e) {
        	e.printStackTrace();
        	throw new DiffException("There was an error applying the Diff");
			
		}
		
		return (T) modified;
	}
	
	public Object applyChange(Object mod, Map<String, Object> diffValues) {
		
		ArrayList<Method> setters = findSetters(mod.getClass());
		
		Iterator<Method> list = setters.listIterator();
		Iterator<?> it = diffValues.entrySet().iterator();
	    
		// loop though all the values in the diff, only changed fields will be found in the diff		
		while (it.hasNext()) {
	        @SuppressWarnings("unchecked")
			Map.Entry<String,Object> pair = (Map.Entry<String,Object>)it.next();
	       	        
	        try {
	        	// retrieve the declared field related to the diff key-value pair
	        	Field field = mod.getClass().getDeclaredField((String) pair.getKey());
	        	
	        	// need to make field accessible, otherwise you can't access the field value
	        	field.setAccessible(true);
	        	
	        	//tried using the isMember() on the class, but this didn't work and couldn't find the child classes
	        	if ( (field.getType().isPrimitive() && !Modifier.isStatic(field.getModifiers())) || 
	        		(field.getType().equals(String.class)) || 
			    	(field.getType().equals(Set.class)) ||
			    	(field.getType().equals(Arrays.class)) || 
			    	(field.getType().equals(String[].class)) ||
			    	(field.getType().equals(Integer[].class)) ||
			    	(field.getType().equals(Double[].class)) ||
			    	(field.getType().equals(List.class)) ||
			    	(field.getType().equals(Map.class)) ) {
	        				        	
	        		while (list.hasNext() ) {
	        			Method setMethod = list.next();
	        			
	        			//finding the setter method will only work if the setters were auto-generated.
	        			String partialSetName = pair.getKey().toString().substring(1);
	        			
	        			if (setMethod.getName().matches("^set[A-Z]"+partialSetName+".*")) {
	        				setMethod.invoke(mod, pair.getValue());
	        				break;
	        			}

	        		}	 
	        	} else {
	        		// recursively checks child object class to apply the changes
	        		applyChange(field.get(mod), (Map<String, Object>) pair.getValue());
		       
		        		
		        }
	        } catch (NoSuchFieldException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
	        
	        it.remove(); 
	    }
		
		
		return mod;		
	}
	
	// finds all public setter methods for a specific class
	static ArrayList<Method> findSetters(Class<?> c) {
	   ArrayList<Method> list = new ArrayList<Method>();
	   Method[] methods = c.getDeclaredMethods();
	   for (Method method : methods) {
		   if (Modifier.isPublic(method.getModifiers()) &&
		      method.getParameterTypes().length != 0) {
		         if (method.getName().matches("^set[A-Z].*") &&
		            method.getReturnType().equals(void.class))
		        	 list.add(method);
		     
		   }
	   
	       
	   }
	   return list;
	}

	public <T extends Serializable> Diff<T> calculate(T original, T modified) throws DiffException {
		
		Diff<T> diff = new Diff<T>();
		
		Map<String, Object> allFields = new HashMap<String, Object>();
		
		// enum status set for entire oject but was unable to use this for display
		if ((null == original) && (null != modified)) {
			diff.setStatus(Status.CREATED);			
			allFields = parameters(modified);
			
		} else if ((null != original) && (null == modified)) {
			diff.setStatus(Status.DELETED);			
			allFields = parameters(null);
			
		} else {
			diff.setStatus(Status.UPDATED);
			
			try {
				// retrieves all modified fields
				allFields = getAllFields(original, modified);			
								
			} catch (Exception e) {
	        	e.printStackTrace();
	        	throw new DiffException("There was an error calculating the Diff");
			}
		}
		
		diff.setFields(allFields);
		diff.setPrettyFields(prettyDiff);
		
		//also investigated the below statement, which uses the overridden object equals method
		//However, this returns a boolean and not a diff object
		
		//assertThat(original).usingRecursiveComparison().isEqualTo(modified);		
		
		return diff;
	}

	// retrieved all changes fields, used a TreeMap to keep the order, so it renders the json display correctly
	public static TreeMap<String, Object> getAllFields(Object original, Object modified) {
		// sets the diff hashmap on the diff object in the calling method
		TreeMap<String, Object> diff = new TreeMap<String, Object>();
		
        
        //HashCode Set used keep track of object relationships and therefore prevent cyclic relationships
		hashcodeList.add(original.hashCode());        
		//Line above dies when cyclic relationship introduced at the point of retrieving the hashcode 
		//it is unable to calculate the hash as it times out when referencing Friend recursively.
		
		List<Field> fields = new ArrayList<Field>();        
        fields.addAll(Arrays.asList(original.getClass().getDeclaredFields()));
        
        try {
        	
        	ListIterator<Field> iterator = fields.listIterator();
        	
        	while (iterator.hasNext()) { 
        		
        		Field field = iterator.next();
		
	        	// need to make field accessible, otherwise you can't access the field value
		    	field.setAccessible(true);
		    	
	        	//tried using the isMember() on the class, but this didn't work and couldn't find the child classes
		    	if ( (field.getType().isPrimitive() && !Modifier.isStatic(field.getModifiers())) || 
		    		 (field.getType().equals(String.class)) || 
		    		 (field.getType().equals(Set.class)) ||
		    		 (field.getType().equals(Arrays.class)) || 
		    		 (field.getType().equals(String[].class)) ||
		    		 (field.getType().equals(Integer[].class)) ||
		    		 (field.getType().equals(Double[].class)) ||
		    		 (field.getType().equals(List.class)) ||
		    		 (field.getType().equals(Map.class)) ) {
		    		
					
						// could not display as per renderer example - normal diff just displays a pretty json 
		    			// and pretty diff was suppose to be a manipulated json to display human-readable format
		    			
		    			
		    			if ((null == field.get(original)) && (null != field.get(modified))) {
		    				prettyDiff.put("Create: "+ field.getName(), " as "+ field.get(modified));
		    				diff.put(field.getName(), field.get(modified));
		    				
		    			} else if ((null != field.get(original)) && (null == field.get(modified))) {
		    				prettyDiff.put("Delete: "+ field.getName(), "");
		    				diff.put(field.getName(), field.get(modified));
		    				
		    			} else if ((null != field.get(original)) && (null != field.get(modified))){
		    				
		    				if (!field.get(original).equals(field.get(modified))) {
		    					prettyDiff.put("Update: "+ field.getName(), " from " + field.get(original) + " to " + field.get(modified));
		    					diff.put(field.getName(), field.get(modified));
		    				}
		    			}
		    		
				} else if (field.get(original) != null && !Modifier.isStatic(field.getModifiers())){
					
					//was suppose to check if hash of the original Object field is in the hashcode list, if so skip
					if (!hashcodeList.contains(field.get(original).hashCode())) {
						TreeMap<String, Object> subClass = getAllFields(field.get(original), field.get(modified));
						
						if (null != subClass || !subClass.isEmpty()) {
							diff.put(field.getName(), subClass);
							
							if ((null == field.get(original)) && (null != field.get(modified))) {
			    				prettyDiff.put("Create: "+ field.getName(), subClass);
			    				
			    			} else if ((null != field.get(original)) && (null == field.get(modified))) {
			    				prettyDiff.put("Delete: "+ field.getName(), subClass);
			    				
			    			} else {
			    				prettyDiff.put("Update: "+ field.getName(), subClass);
			    			}
						}
					}
				}
		    	
		    	
		    }
        	
        } catch (Exception e) {
        	e.printStackTrace();
        }
        return diff;
    }

	// generically sets up Created or Deleted object
	public static Map<String, Object> parameters(Object obj) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		if (null != obj) {
	        for (Field field : obj.getClass().getDeclaredFields()) {
	            field.setAccessible(true);
	            try { 
	            	map.put(field.getName(), field.get(obj)); 
	            } catch (Exception e) { }
	        }
		}
        return map;
    }
}
