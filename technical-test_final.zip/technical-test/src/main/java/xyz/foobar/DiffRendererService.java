package xyz.foobar;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class DiffRendererService implements DiffRenderer{


	public String render(Diff<?> diff) throws DiffException {

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonParser jp = new JsonParser();
		//Had trouble implementing pretty Diff, so I just outputted the normal diff
		JsonElement je = jp.parse(diff.getFields().toString());
		
		return gson.toJson(je);
	}

}
