package xyz.foobar;

import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;

/**
 * The object representing a diff.
 * Implement this class as you see fit. 
 *
 */
public class Diff<T extends Serializable> {

	public enum Status {
	    CREATED,
	    UPDATED,
	    DELETED
	}
	
	Map<String, Object> fields = new TreeMap<String, Object>();
	Map<String, Object> prettyFields = new TreeMap<String, Object>();
	Status status; 

	public Map<String, Object> getFields() {
		return fields;
	}

	public void setFields(Map<String, Object> fields) {
		this.fields = fields;
	}

	public Map<String, Object> getPrettyFields() {
		return prettyFields;
	}

	public void setPrettyFields(Map<String, Object> prettyFields) {
		this.prettyFields = prettyFields;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status created) {
		this.status = created;
	}
}
