package xyz.foobar.test;

import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import xyz.foobar.Diff;
import xyz.foobar.DiffEngine;
import xyz.foobar.DiffException;
import xyz.foobar.DiffRendererService;
import xyz.foobar.DiffService;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PersonTest {
	
	static Person person = new Person();
	static Person personModified = new Person();

	public void setup() {
						
		Pet pet2 = new Pet();		
		pet2.setName("Rufus");
		pet2.setType("Dog");
		
		Set<String> nickNames = new HashSet<String>(Arrays.asList("JD","Jamie"));
		
		Person friend = new Person();
		friend.setFirstName("James");
		friend.setSurname("White");
		friend.setFriend(null);
		friend.setPet(pet2);
		friend.setNickNames(nickNames);
//		friend.setCars(null);
		friend.setFavouriteColours(null);
		friend.setTelephoneNumbers(null);
		
		Pet pet = new Pet();		
		pet.setName("Gizmo");
		pet.setType("Dog");
		
		Set<String> nickNames2 = new HashSet<String>(Arrays.asList("SD","Sarz"));
		
		String[] cars = {"BMW","Range Rover"};
		List<String> favouriteColours = new ArrayList<String>();
		favouriteColours.add("Pink");
		favouriteColours.add("Yellow");
		Map<String, String> numbers = new HashMap<String, String>();
		numbers.put("cell", "0831236458");
		numbers.put("home", "0114563458");
		
		person.setFirstName("Sarah");
		person.setSurname("Duck");
		person.setFriend(friend);
		person.setPet(pet);
		person.setNickNames(nickNames2);
//		person.setCars(cars);
		person.setFavouriteColours(favouriteColours);
		person.setTelephoneNumbers(numbers);

		
		Set<String> nickNamesModified = new HashSet<String>(Arrays.asList("SD","Sarz"));
		
		Pet petModified = new Pet();		
		petModified.setName("Gizmo");
		petModified.setType("Cat");
		
		String[] carsModified = {"BMW","Fortuner"};
		List<String> favouriteColoursModified = new ArrayList<String>();
		favouriteColoursModified.add("Pink");
		favouriteColoursModified.add("Green");
		
		personModified.setFirstName("Sarah");
		personModified.setSurname("Bing");
		personModified.setFriend(friend);
		personModified.setPet(petModified);
		personModified.setNickNames(nickNamesModified);
//		personModified.setCars(carsModified);
		personModified.setFavouriteColours(favouriteColoursModified);
		personModified.setTelephoneNumbers(numbers);
		
	}
	
	@Test
	public void testUpdated() 
	{
		setup();
		
		//test set, array, list, map etc
		//problem with a StringArray, this was removed.
		
		DiffService diffSer = new DiffService();
		try {
			Diff diff = diffSer.calculate(person, personModified);
			
			assertNotNull(diff);
			
			DiffRendererService diffRenderer = new DiffRendererService();	
			System.out.println("\nUpdated: ");
			System.out.println(diffRenderer.render(diff));
			
			// changes apply successfully but nothing was done with the output.
			Person updatedPerson = diffSer.apply(person, diff);
			
		} catch (DiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testCreated() 
	{
		setup();
		
		//test set, array, list, map etc
		//problem with a StringArray, this was removed.
		
		DiffService diffSer = new DiffService();
		try {
			Diff diff = diffSer.calculate(null, personModified);
			
			assertNotNull(diff);
			
			DiffRendererService diffRenderer = new DiffRendererService();	
			System.out.println("\nCreated: ");
			System.out.println(diffRenderer.render(diff));
						
			// need to fix calculateDiff for this scenario, not calling the function recursively
			//Person updatedPerson = diffSer.apply(person, diff);
			
		} catch (DiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testDeleted() 
	{
		setup();
		
		//test set, array, list, map etc
		//problem with a StringArray, this was removed.
		
		DiffService diffSer = new DiffService();
		try {
			Diff diff = diffSer.calculate(person, null);
			
			assertNotNull(diff);
			
			DiffRendererService diffRenderer = new DiffRendererService();	
			System.out.println("\nDeleted: ");
			System.out.println(diffRenderer.render(diff));
			
			// shouldn't need to call apply for this scenario
			//Person updatedPerson = diffSer.apply(person, diff);
			
		} catch (DiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
